import { Component } from "@angular/core";

@Component({
    selector:'unauth',
    templateUrl:'unauthorized.component.html'
})
export class UnAuthorizedComponent{



}