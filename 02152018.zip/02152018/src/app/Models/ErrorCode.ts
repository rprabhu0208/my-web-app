export enum ErrorCode {
    invalidUserIDPassword = "Invalid user id or password ",
    userDoesNotExist =  "Email id does not exists"
}